# v0.1.8

- Add : Difficulty Preset for Custom Difficulty.
- Add : Changelog in Thunderstore
- Modify : Now All custom change are save.
- Modify : Shop Multiplier accepte value : X.X  
- All Vaultline Map doors have been removed for Netowkr performance

# v0.1.7 

- Fix an Issue were the generation was active on lobby and menu
- Optimization for the generation

Note: After many ask , the mod PlayerScaling is not supported. For now you will have to unistall the mod.

# v0.1.6

- Change the button position
- Modify the readme file

# v0.1.3 , v0.1.4 and v0.1.5

- The difficulty is now saved after your session.
- Fixed an issue where the game could not create the save file
- Fixed an issue where rare type enemies were spawning too often

#v0.1.2

- Add Difficulty Save

#v0.1.1

- Fix : Multiplier shop

#v0.1.0

- Launch the mod MoreDifficulty
- Add a new system of Difficulty
- Add a custom Difficulty
- Rework of the Generation of the map.
